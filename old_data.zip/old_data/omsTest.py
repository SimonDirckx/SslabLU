import numpy as np
import pdo.pdo as pdo
import solver.solver as solverWrap
import matAssembly.matAssembler as mA
import oms.oms as oms
from scipy.sparse.linalg import gmres


import numpy as np
import pdo.pdo as pdo
import solver.solver as solverWrap
import multiSlab as MS
import matAssembly.matAssembler as mA
import matplotlib.pyplot as plt
import geometry.standardGeometries as stdGeom
import geometry.skeleton as skelTon
import time
import hps.hps_multidomain as HPS
import hps.geom as hpsGeom
from scipy.sparse        import block_diag
import scipy.sparse as sparse
import scipy.sparse.linalg as splinalg
from scipy import interpolate
from scipy.interpolate import griddata
from scipy.sparse.linalg   import LinearOperator
from scipy.sparse.linalg import gmres
from solver.solver import stMap
import matAssembly.matAssembler as mA
class gmres_info(object):
    def __init__(self, disp=False):
        self._disp = disp
        self.niter = 0
        self.resList=[]
    def __call__(self, rk=None):
        self.niter += 1
        self.resList+=[rk]
        if self._disp:
            print('iter %3i\trk = %s' % (self.niter, str(rk)))


#nwaves = 24.623521102434587
nwaves = 24.673521102434584
kh = (nwaves+0.03)*2*np.pi+1.8

def bfield(xx):
    
    mag   = 0.930655
    width = 2500; 
    
    b = np.zeros(shape = (xx.shape[0],))
    
    dist = 0.04
    x0=0.1+0.5*dist; x1 = 0.50; x2 = x1+2.5*dist; x3= 0.9
    y0=0.1+0.5*dist; y1 = 0.50; y2 = y1+2.5*dist; y3= 0.9
    
    # box of points [x0,x1] x [y0,y1]
    for x in np.arange(x0,x1,dist):
        for y in np.arange(y0,y1,dist):
            xx_sq_c = (xx[:,0] - x)**2 + (xx[:,1] - y)**2
            b += mag * np.exp(-width * xx_sq_c)

    # box of points [x0,x1] x [y0,y2]
    for x in np.arange(x2,x3,dist):
        for y in np.arange(y0,y2-0.5*dist,dist):
            xx_sq_c = (xx[:,0] - x)**2 + (xx[:,1] - y)**2
            b += mag * np.exp(-width * xx_sq_c)
            
    # box of points [x0,x3] x [y2,y3]
    for x in np.arange(x0,x3,dist):
        for y in np.arange(y2,y3,dist):
            xx_sq_c = (xx[:,0] - x)**2 + (xx[:,1] - y)**2
            b += mag * np.exp(-width * xx_sq_c)    
    
    kh_fun = -kh**2 * (1 - b)
    return kh_fun


def c11(p):
    return np.ones(shape=(p.shape[0],))
def c22(p):
    return np.ones(shape=(p.shape[0],))
def c(p):
    return bfield(p)

vHelmholtz  =   pdo.PDO2d(c11,c22,None,None,None,c)

def bc(p):
    return np.ones(shape=(p.shape[0],))

bndsOm = [[0.,0.],[1.,1.]]

def gb(p):
    return np.abs(p[0]-bndsOm[0][0])<1e-14 or np.abs(p[0]-bndsOm[1][0])<1e-14 or np.abs(p[1]-bndsOm[0][1])<1e-14 or np.abs(p[1]-bndsOm[1][1])<1e-14


H = 1./4.
N = (int)(1./H)
p = 32
a = 1./8.


slabList = []
connectivity = []
for i in range(N-1):
    bnds=np.array([[i*H,0.],[(i+2)*H,1.]])
    slabList+=[oms.slab(bnds,gb)]
    if i==0:
        connectivity+=[i+1]
    elif i==N-2:
        connectivity+=[i-1]
    else:
        connectivity+=[i-1,i+1]
assembler = mA.denseMatAssembler()
opts=solverWrap.solverOptions('hps',p,a)
hpsSolver = solverWrap.solverWrapper(opts)
ms = oms.multiSlab(slabList,connectivity,assembler,vHelmholtz,gb,hpsSolver)
Stot,rhstot = ms.construct_Smat_and_rhs(bc)
globalDofs = ms.globalDofs
gInfo = gmres_info()
stol = 1e-8*H*H
print("Gmres start")
uhat,info   = gmres(Stot,rhstot,rtol=stol,callback=gInfo,maxiter=500,restart=500)
res = Stot@uhat-rhstot

print("=============SUMMARY==============")
print("H                        = ",'%10.3E'%H)
print("ord                      = ",p)
print("L2 rel. res              = ", np.linalg.norm(res)/np.linalg.norm(rhstot))
print("GMRES iters              = ", gInfo.niter)
print("==================================")


uitot = np.zeros(shape=(0,1))
btot = np.zeros(shape=(0,))
XXtot = np.zeros(shape=(0,2))
dofs = 0
N = len(slabList)+1
for i in range(N):
    xl = i*H
    xr = (i+1)*H
    print("xr = ",xr)
    geom = hpsGeom.BoxGeometry(np.array([[xl,0.],[xr,1.]]))
    disc = HPS.HPSMultidomain(vHelmholtz, geom, a, p)
    XX = disc._XX
    XXb = XX[disc.Jx,:]
    XXi = XX[disc.Ji,:]
    Ir = [i for i in range(len(disc.Jx)) if np.abs(XXb[i,0]-xr)<1e-10 and XXb[i,1]>1e-10 and XXb[i,1]<1-1e-10]
    Il = [i for i in range(len(disc.Jx)) if np.abs(XXb[i,0]-xl)<1e-10 and XXb[i,1]>1e-10 and XXb[i,1]<1-1e-10]
    bvec = np.ones(shape=(len(disc.Jx),1))
    if i>0:
        bvec[Il,0] = uhat[globalDofs[i-1]]
    if i<N-1:
        bvec[Ir,0] = uhat[globalDofs[i]]
    dofs+=bvec.shape[0]
    ui = disc.solve_dir_full(bvec)
    uitot=np.append(uitot,ui,axis=0)
    XXfull=disc._XXfull
    XXtot=np.append(XXtot,XXfull,axis=0)

dofs+=XXtot.shape[0]
print('u shape = ',uitot.shape)
print('XX shape = ',XXtot.shape)
print('total dofs = ',dofs)

resolution = 1000
min_x = 0.
max_x = 1.
min_y = 0.
max_y = 1.
grid_x, grid_y    = np.mgrid[min_x:max_x:resolution*1j, min_y:max_y:resolution*1j]

grid_solution           = griddata(XXtot, uitot[:,0], (grid_x, grid_y), method='cubic').T

plot_pad=0.
max_sol = np.max(grid_solution[:])
min_sol = np.min(grid_solution[:])
plt.figure(0)
plt.imshow(grid_solution, extent=(min_x-plot_pad,max_x+plot_pad,\
                                    min_y-plot_pad,max_y+plot_pad),\
                                        #vmin=min_sol, vmax=max_sol,\
                origin='lower',cmap = 'jet')
plt.colorbar()
plt.show()