import numpy as np
import pdo.pdo as pdo
import solver.solver as solverWrap
import matAssembly.matAssembler as mA
import oms.oms as oms
from scipy.sparse.linalg import gmres
import scipy.special as special

import numpy as np
import pdo.pdo as pdo
import solver.solver as solverWrap
import multiSlab as MS
import matAssembly.matAssembler as mA
import matplotlib.pyplot as plt
import geometry.standardGeometries as stdGeom
import geometry.skeleton as skelTon
import time
import hps.hps_multidomain as HPS
import hps.geom as hpsGeom
from scipy.sparse        import block_diag
import scipy.sparse as sparse
import scipy.sparse.linalg as splinalg
from scipy import interpolate
from scipy.interpolate import griddata
from scipy.sparse.linalg   import LinearOperator
from scipy.sparse.linalg import gmres
from solver.solver import stMap
import matAssembly.matAssembler as mA
class gmres_info(object):
    def __init__(self, disp=False):
        self._disp = disp
        self.niter = 0
        self.resList=[]
    def __call__(self, rk=None):
        self.niter += 1
        self.resList+=[rk]
        if self._disp:
            print('iter %3i\trk = %s' % (self.niter, str(rk)))

def join(slab1,slab2,periodic=False,period = 1.,transform = None):
    xll = slab1[0][0]
    xrl = slab1[1][0]
    yll = slab1[0][1]
    yrl = slab1[1][1]

    xlr = slab2[0][0]
    xrr = slab2[1][0]
    ylr = slab2[0][1]
    yrr = slab2[1][1]
    if xll<xlr:
        slab = oms.slab(np.array([[xll,yll],[xrr,yrr]]))
    else:
        slab = oms.slab(np.array([[xll-period,yll],[xrr,yrr]]))
    return slab


#nwaves = 24.623521102434587
nwaves = 2.1#24.673521102434584
kh = 2.*np.pi#(nwaves+0.03)*2*np.pi+1.8


def c11(p):
    return np.ones(shape=(p.shape[0],))
def c22(p):
    return np.ones(shape=(p.shape[0],))
def c(p):
    return -kh*kh*np.ones(shape = (p.shape[0],))

Helmholtz  =   pdo.PDO2d(c11,c22,None,None,None,c)

def bc(p):
    return np.sin(kh*p[:,0])

bndsOm = [[0.,0.],[1.,1.]]

def gb(p):
    return np.abs(p[0]-bndsOm[0][0])<1e-14 or np.abs(p[0]-bndsOm[1][0])<1e-14


H = 1./4.
N = (int)(1./H)
p = 32
a = 1./8.


slabList = []
i2i_connectivity = []
i2s_connectivity = []
periodic = True
period   = 1

# set number of interfaces
if periodic:
    Nifs = N
else:
    Nifs = (N-1)

xc_list = []

#construct single slabs (no periodicity needed)

singleSlabs = []
for i in range(N):
    bnds = [[i*H,0.],[(i+1)*H,1.]]
    singleSlabs +=[bnds]

for i in range(Nifs):
    if periodic:
        i2s_connectivity+=[[(i-1)%N,i%N]]
        i2i_connectivity+=[[(i-1)%Nifs,(i+1)%Nifs]]
        xc_list+=[i*H]
    else:
        xc_list+=[(i+1)*H]
        i2s_connectivity+=[[i,i+1]]
        if i==0:
            i2i_connectivity+=[[-1,i+1]]
        elif i==Nifs-1:
            i2i_connectivity+=[[i-1,-1]]
        else:
            i2i_connectivity+=[[i-1,i+1]]

#build double slabs
doubleSlabs = []
for i2s in range(len(i2s_connectivity)):
    [il,ir] = i2s_connectivity[i2s]
    print("il,ir = ",il,",",ir)
    doubleSlabs+=[join(singleSlabs[il],singleSlabs[ir],periodic,period)]
assembler = mA.denseMatAssembler()
opts=solverWrap.solverOptions('hps',p,a)
hpsSolver = solverWrap.solverWrapper(opts)
ms = oms.multiSlab(doubleSlabs,i2i_connectivity,assembler,Helmholtz,gb,hpsSolver)
Stot,rhstot = ms.construct_Smat_and_rhs(bc)

globalDofs = ms.globalDofs
gInfo = gmres_info()
stol = 1e-8*H*H
print("Gmres start")
uhat,info   = gmres(Stot,rhstot,rtol=stol,callback=gInfo,maxiter=500,restart=500)
res = Stot@uhat-rhstot

print("=============SUMMARY==============")
print("H                        = ",'%10.3E'%H)
print("ord                      = ",p)
print("L2 rel. res              = ", np.linalg.norm(res)/np.linalg.norm(rhstot))
print("GMRES iters              = ", gInfo.niter)
print("==================================")

plt.figure(0)
plt.plot(uhat)
plt.show()


uitot = np.zeros(shape=(0,1))
btot = np.zeros(shape=(0,))
XXtot = np.zeros(shape=(0,2))
dofs = 0
N = len(singleSlabs)
for i in range(N):
    xl = i*H
    xr = (i+1)*H
    print("xr = ",xr)
    geom = hpsGeom.BoxGeometry(np.array([[xl,0.],[xr,1.]]))
    disc = HPS.HPSMultidomain(Helmholtz, geom, a, p)
    XX = disc._XX
    XXb = XX[disc.Jx,:]
    XXi = XX[disc.Ji,:]
    Ir = [i for i in range(len(disc.Jx)) if np.abs(XXb[i,0]-xr)<1e-10 and XXb[i,1]>1e-10 and XXb[i,1]<1-1e-10]
    Il = [i for i in range(len(disc.Jx)) if np.abs(XXb[i,0]-xl)<1e-10 and XXb[i,1]>1e-10 and XXb[i,1]<1-1e-10]
    bvec = np.zeros(shape=(XXb.shape[0],1))
    bvec[:,0] = bc(XXb)
    bvec[Il,0] = uhat[globalDofs[i]]
    #bvec[Ir,0] = uhat[globalDofs[(i+1)%len(doubleSlabs)]]
    dofs += bvec.shape[0]
    ui = disc.solve_dir_full(bvec)
    uitot=np.append(uitot,ui,axis=0)
    XXfull=disc._XXfull
    XXtot=np.append(XXtot,XXfull,axis=0)

dofs+=XXtot.shape[0]
print('u shape = ',uitot.shape)
print('XX shape = ',XXtot.shape)
print('total dofs = ',dofs)

resolution = 1000
min_x = 0.
max_x = 1.
min_y = 0.
max_y = 1.
grid_x, grid_y    = np.mgrid[min_x:max_x:resolution*1j, min_y:max_y:resolution*1j]

grid_solution           = griddata(XXtot, uitot[:,0], (grid_x, grid_y), method='cubic').T

plot_pad=0.
max_sol = np.max(grid_solution[:])
min_sol = np.min(grid_solution[:])
plt.figure(0)
plt.imshow(grid_solution, extent=(min_x-plot_pad,max_x+plot_pad,\
                                    min_y-plot_pad,max_y+plot_pad),\
                                        #vmin=min_sol, vmax=max_sol,\
                origin='lower',cmap = 'jet')
plt.colorbar()
plt.show()
