import numpy as np
import pdo.pdo as pdo
import solver.solver as solverWrap
import multiSlab as MS
import matAssembly.matAssembler as mA
import matplotlib.pyplot as plt
import geometry.standardGeometries as stdGeom
import geometry.skeleton as skelTon
import time
import hps.hps_multidomain as HPS
import hps.geom as hpsGeom
from scipy.sparse        import block_diag
import scipy.sparse as sparse
import scipy.sparse.linalg as splinalg
from scipy import interpolate
from scipy.interpolate import griddata
from scipy.sparse.linalg   import LinearOperator
from scipy.sparse.linalg import gmres
from solver.solver import stMap
import matAssembly.matAssembler as mA
from matplotlib.patches import Polygon
from hps.geom              import BoxGeometry, ParametrizedGeometry2D,ParametrizedGeometry3D
import matplotlib as mpl
from mpl_toolkits.axes_grid1 import make_axes_locatable
from scipy.spatial import Delaunay 

kh = 2*np.pi*1.02*np.sqrt(3)

def bfield(xx,kh):
    
    b = np.ones(shape = (xx.shape[0],))
    
    kh_fun = -kh**2 * b
    return kh_fun


def c11(p):
    return np.ones(shape=(p.shape[0],))
def c22(p):
    return np.ones(shape=(p.shape[0],))
def c33(p):
    return np.ones(shape=(p.shape[0],))
def c(p):
    return bfield(p,kh)
Lapl=pdo.PDO3d(c11,c22,c33,None,None,None,None,None,None,c)


bnds = [[0.,0.,0],[1.,1.,1.]]
box_geom   = np.array([[0,0,0],[1.,1.,1.]])
Om=stdGeom.Box(bnds)

def bc(p):
    return np.sin((kh/np.sqrt(3))*p[0])*np.sin((kh/np.sqrt(3))*p[1])*np.sin((kh/np.sqrt(3))*p[2])

def gb(p):
    return np.abs(p[0]-bnds[0][0])<1e-14 or np.abs(p[0]-bnds[1][0])<1e-14 or np.abs(p[1]-bnds[0][1])<1e-14 or np.abs(p[1]-bnds[1][1])<1e-14 or np.abs(p[2]-bnds[0][2])<1e-14 or np.abs(p[2]-bnds[1][2])<1e-14
def exact_sol(p):
    return bc(p)

H = 1./4.
N = (int)(bnds[1][0]/H)
p = 10
a = H/4.


uitot = np.zeros(shape=(0,1))
uitot_exact = np.zeros(shape=(0,1))
btot = np.zeros(shape=(0,))
XXtot = np.zeros(shape=(0,2))
dofs = 0

uhat = np.load('uhat_3dBox.npy')

for i in range(N):
    xl = i*H
    xr = (i+1)*H
    z00 = bnds[0][2]
    z01 = bnds[1][2]
    geom = hpsGeom.BoxGeometry(np.array([[xl,0.,z00],[xr,1.,z01]]))
    zmid = (z00+z01)/2
    disc = HPS.HPSMultidomain(Lapl, geom, a, p)
    print("hps done")
    XX = disc._XX
    print("XX done")
    XXb = XX[disc.Jx,:]
    print("XXi done")
    XXi = XX[disc.Ji,:]
    print("XXb done")
    Ir  = [i for i in range(len(disc.Jx)) if np.abs(XXb[i,0]-xr)<1e-12 and XXb[i,1]>1e-12 and XXb[i,1]<1-1e-12]
    Il  = [i for i in range(len(disc.Jx)) if np.abs(XXb[i,0]-xl)<1e-12 and XXb[i,1]>1e-12 and XXb[i,1]<1-1e-12]
    Igb = [i for i in range(len(disc.Jx)) if gb(XXb[i,:])]
    nc = len(Ir)
    print("Is done")
    bvec = np.zeros(shape=(len(disc.Jx),1))
    bvec[Igb,0]=[bc(XXb[i,:]) for i in Igb]
    if i>0:
        bvec[Il,0] = uhat[(i-1)*nc:i*nc]
    if i<N-1:
        bvec[Ir,0] = uhat[i*nc:(i+1)*nc]
    print("b done")
    dofs+=bvec.shape[0]-nc
    ui = disc.solve_dir_full(bvec)
    print("u done")
    dofs+=ui.shape[0]
    zztot = disc._XXfull

    idxz0 = [i for i in range(zztot.shape[0]) if np.abs(zztot[i,2]-zmid)<1e-10]
    print("len(idxz0) = ",len(idxz0))
    zz0 = zztot[idxz0,:]
    ui_exact = np.reshape(np.array([exact_sol(zz0[i,:]) for i in range(zz0.shape[0])]),newshape=(zz0.shape[0],1))
    XXtot=np.append(XXtot,zz0[:,0:2],axis=0)
    uitot=np.append(uitot,ui[idxz0,:],axis=0)
    uitot_exact=np.append(uitot_exact,ui_exact,axis=0)
    
    Inr = [i for i in range(XXb.shape[0]) if not i in Ir]
    XXbnr = XXb[Inr,:]
    zzb = XXb[Inr,:]
    
    idxz00 = [i for i in range(zzb.shape[0]) if np.abs(zzb[i,2]-zmid)<1e-10]
    zzb0=zzb[idxz00,:]
    XXtot=np.append(XXtot,zzb0[:,0:2],axis=0)
    uitot=np.append(uitot,bvec[idxz00],axis=0)
    ui_exact = np.reshape(np.array([exact_sol(zzb0[i,:]) for i in range(zzb0.shape[0])]),newshape=(zzb0.shape[0],1))
    uitot_exact=np.append(uitot_exact,ui_exact,axis=0)
    del geom,disc,zztot,XX,XXi,XXb,ui,bvec,zz0,Ir,Il


print('u shape = ',uitot.shape)
print('XX shape = ',XXtot.shape)
print('total dofs = ',dofs)
print('rel err = ',np.linalg.norm(uitot-uitot_exact)/np.linalg.norm(uitot_exact))
print('inf err = ',np.linalg.norm(uitot-uitot_exact,ord=np.inf))

resolution = 1000
min_x = np.min(XXtot[:,0])#bnds[0][0]
max_x = np.max(XXtot[:,0])#bnds[1][0]
min_y = np.min(XXtot[:,1])#bnds[0][1]
max_y = np.max(XXtot[:,1])#bnds[1][1]
xpts = np.linspace(min_x,max_x,resolution)
ypts = np.linspace(min_y,max_y,resolution)
grid_x, grid_y    = np.mgrid[min_x:max_x:resolution*1j, min_y:max_y:resolution*1j]

grid_solution           = griddata(XXtot, uitot[:,0], (grid_x, grid_y), method='cubic').T
print("grid_solution shape = ",grid_solution.shape)

print("grid_x shape = ",grid_x.shape)

gsqXY = np.zeros(shape=(grid_solution.shape[0]*grid_solution.shape[0],2))
for i in range(resolution):
    for j in range(resolution):
        p=np.zeros(shape=(1,3))
        p[0,:] = np.array([xpts[i],ypts[j],.5])
        gsqXY[i+j*resolution,:] = [xpts[i],ypts[j]]
tri = Delaunay(gsqXY)
plt.figure(0)
gsol = grid_solution.flatten()
plt.tripcolor(gsqXY[:,0],gsqXY[:,1],gsol,triangles = tri.simplices.copy(),cmap='jet',shading='gouraud')
plt.colorbar()
plt.axis('equal')
plt.savefig('boxHelmholtz3D.png', transparent=True,format='png',bbox_inches='tight')
plt.show()
