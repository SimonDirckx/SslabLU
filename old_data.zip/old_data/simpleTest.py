import numpy as np

u=None
v=np.ones(shape=(10,))
print(np.array(u)-v)